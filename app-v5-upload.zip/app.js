'use strict';
/* ===== Config ===== */
const AI_URL = '';            // вставь сюда адрес своего Cloudflare Worker, например 'https://vecher-ai.NAME.workers.dev'
const STORE_KEY = 'evening.v5';
const VERSION = '0.5.0-beta';

/* ===== Helpers ===== */
const $ = (s, r = document) => r.querySelector(s);
const ic = n => (typeof IC !== 'undefined' && IC[n]) || '';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad = n => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fromKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const WD = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
const WD_LONG = ['в воскресенье','в понедельник','во вторник','в среду','в четверг','в пятницу','в субботу'];
const MON = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const MON_N = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const fmtDay = d => `${WD[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}`;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c); };
const RATE_LBL = {1:'Очень тяжело', 2:'Тяжело', 3:'Ровно', 4:'Неплохо', 5:'Хорошо'};

/* ===== Storage ===== */
const DEFAULT = () => ({ v: 5, profile: { name: '', onboarded: false, glass: true, aiUrl: '' }, entries: [], chat: { messages: [], step: 0, startedAt: null } });
function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return DEFAULT();
    const d = JSON.parse(raw);
    const base = DEFAULT();
    return { ...base, ...d, profile: { ...base.profile, ...(d.profile || {}) }, entries: Array.isArray(d.entries) ? d.entries.filter(validEntry) : [], chat: { ...base.chat, ...(d.chat || {}) } };
  } catch (e) { return DEFAULT(); }
}
function validEntry(e) { return e && typeof e === 'object' && typeof e.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(e.date); }
let S = load();
function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) { toast('Не получилось сохранить: память браузера переполнена'); } }

/* ===== Data logic ===== */
const sorted = () => [...S.entries].sort((a, b) => (b.date + (b.created || '')).localeCompare(a.date + (a.created || '')));
const entryOn = k => sorted().find(e => e.date === k);
function ratingOn(k) { const e = S.entries.filter(x => x.date === k && x.rating).sort((a, b) => (b.created || '').localeCompare(a.created || ''))[0]; return e ? e.rating : null; }
function last7() { const t = new Date(); return Array.from({ length: 7 }, (_, i) => { const d = addDays(t, i - 6); const k = dayKey(d); return { d, k, r: ratingOn(k) }; }); }
function streak() {
  let d = new Date(); if (!entryOn(dayKey(d))) d = addDays(d, -1);
  let n = 0; while (entryOn(dayKey(d))) { n++; d = addDays(d, -1); } return n;
}
function weekMoves() {
  const from = dayKey(addDays(new Date(), -6));
  const ms = S.entries.filter(e => e.move && e.date >= from);
  return { total: ms.length, done: ms.filter(e => e.moveDone).length };
}
const openMove = () => sorted().find(e => e.move && !e.moveDone);
function pattern() {
  if (S.entries.length < 6) return null;
  const ks = S.entries.map(e => e.date).sort();
  const span = (fromKey(ks[ks.length - 1]) - fromKey(ks[0])) / 864e5;
  if (span < 14) return null;
  const heavy = S.entries.filter(e => e.rating && e.rating <= 2);
  if (heavy.length < 3) return null;
  const cnt = Array(7).fill(0); heavy.forEach(e => cnt[fromKey(e.date).getDay()]++);
  const max = Math.max(...cnt), wd = cnt.indexOf(max);
  if (max < 2 || max / heavy.length < 0.4) return null;
  return { wd, max, total: heavy.length };
}
function verdict() {
  const h = new Date().getHours();
  const today = entryOn(dayKey());
  const heavy = last7().filter(x => x.r && x.r <= 2).length;
  if (!S.entries.length) return { w: 'СТАРТ', t: 'Первый разговор — пять минут. Без оценок и советов сверху.' };
  if (today && today.rating) {
    if (today.rating <= 2) return { w: 'ВЫДОХ', t: 'Тяжёлый день записан. Ляг пораньше, завтра — один ход.' };
    if (today.rating >= 4) return { w: 'РЫВОК', t: 'Хороший день. Держи ход на завтра и не распыляйся.' };
    return { w: 'РОВНО', t: 'Обычный день. Ход на завтра записан — этого достаточно.' };
  }
  if (heavy >= 3) return { w: 'ДЕРЖИСЬ', t: `${heavy} тяжёлых ${plural(heavy, 'вечер', 'вечера', 'вечеров')} за неделю. Напиши сегодня живому человеку.` };
  const om = openMove();
  if (h < 17 && om) return { w: 'ХОД', t: `Сегодня: «${trim(om.move, 60)}»` };
  return { w: 'ВЕЧЕР', t: 'Время выговориться. Пять минут, и день не потащится в ночь.' };
}
const trim = (s, n) => { s = String(s || '').trim(); return s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s; };

/* ===== Crisis detection (on device) ===== */
const CRISIS_RE = new RegExp([
  'покончить с собой','покончу с собой','суицид','самоубий','убить себя','убью себя','не хочу жить','не хочется жить','хочу умереть','лучше бы меня не было','лучше умереть','повешусь','повеситься','порезать себя','режу себя','наглотаться таблеток','выйти в окно','шагнуть с крыши','нет смысла жить',
  'покінчити з собою','не хочу жити','хочу померти','самогубств','вбити себе','вб\'ю себе','краще б мене не було',
  'kill myself','suicide','suicidal','end my life','want to die','self[- ]?harm','hurt myself','better off dead'
].join('|'), 'i');
const isCrisis = t => CRISIS_RE.test(String(t || '').replace(/ё/g, 'е'));

/* ===== UI basics ===== */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 2600); }
function applyGlass() { document.body.dataset.g = S.profile.glass ? 'clear' : 'none'; }
const BLOBS = {
  home: [[200,140,240,'#FF4FA0'],[-90,290,280,'#3FD46A'],[-60,470,220,'#D5FF43'],[200,600,220,'#FF8A3D']],
  chat: [[200,280,260,'#FF5A4E'],[-90,420,240,'#FF4FA0'],[170,560,220,'#3FD46A'],[-60,640,200,'#FF8A3D']],
  journal: [[-80,160,240,'#FF5A4E'],[220,420,240,'#FF8A3D'],[-60,500,220,'#D5FF43'],[220,640,200,'#FF4FA0']],
  other: [[180,60,240,'#D5FF43'],[-90,360,260,'#FF4FA0'],[200,620,220,'#3FD46A']]
};
function setBg(name) {
  const set = BLOBS[name] || BLOBS.other;
  $('#blobs').innerHTML = set.map(([x, y, s, c]) => `<div class="blob" style="left:${x}px;top:${y}px;width:${s}px;height:${s}px;background:${c}"></div>`).join('');
  const ph = $('#bgphoto');
  if (name === 'chat') { ph.style.cssText = 'top:110px;background-image:url(img/evening.webp);background-position:center 60%;opacity:.7'; }
  else if (name === 'journal') { ph.style.cssText = 'top:120px;background-image:url(img/journal.webp);opacity:.7'; }
  else ph.style.opacity = 0;
}

/* ===== Router ===== */
const SCREENS = ['onboarding', 'home', 'chat', 'wrap', 'journal', 'settings'];
let current = 'loading';
function go(name, push = true) {
  if (!S.profile.onboarded && name !== 'onboarding') name = 'onboarding';
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('on', s.id === name));
  current = name;
  RENDER[name] && RENDER[name]();
  setBg(name);
  const showBar = ['home', 'journal'].includes(name);
  const bar = $('#bar'); bar.hidden = !showBar; if (showBar) renderBar(name);
  $('#composer').hidden = name !== 'chat';
  if (push && location.hash !== '#' + name) history.pushState({ s: name }, '', '#' + name);
  window.scrollTo(0, 0);
}
window.addEventListener('popstate', () => { const h = location.hash.slice(1); go(SCREENS.includes(h) ? h : 'home', false); });
function renderBar(on) {
  const tab = (k, i, l) => `<button type="button" data-go="${k}" aria-label="${l}" ${on === k ? 'aria-current="page"' : ''}>${ic(i)}</button>`;
  $('#bar').innerHTML = `<div class="tabs">${tab('home', 'layout-grid', 'Сегодня')}${tab('chat', 'message-circle', 'Разговор')}${tab('journal', 'book-open', 'Журнал')}</div>` +
    (on === 'journal' ? `<button type="button" class="fab" data-act="new-entry" aria-label="Новая запись">${ic('plus')}</button>` : `<button type="button" class="cta" data-go="chat">${ic('mic')}Выговориться</button>`);
}
document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]'); if (g) { e.preventDefault(); go(g.dataset.go); return; }
  const a = e.target.closest('[data-act]'); if (a) { e.preventDefault(); ACT[a.dataset.act] && ACT[a.dataset.act](a); }
});

/* ===== Onboarding ===== */
let obStep = 0;
function renderOnboarding() {
  const steps = `<div class="steps" aria-hidden="true">${[0,1,2].map(i => `<i class="${i <= obStep ? 'on' : ''}"></i>`).join('')}</div>`;
  let body = '';
  if (obStep === 0) body = `<h1>Вечером можно выговориться</h1><p class="lead">Пять минут разговора, короткий итог дня и один маленький ход на завтра. Без оценок и умных советов сверху.</p>
    <label class="lbl" for="obName">Как к тебе обращаться? (можно пропустить)</label><input class="field" id="obName" maxlength="24" autocomplete="off" value="${esc(S.profile.name)}" placeholder="Имя или прозвище">
    <div class="actions"><button class="btn lime" data-act="ob-next">Дальше</button></div>`;
  if (obStep === 1) body = `<h1>Это ИИ, не человек</h1><p class="lead">Собеседник здесь — языковая модель. Она не врач и не психолог, может ошибаться и не ставит диагнозов.</p>
    <ul><li class="card">${ic('message-circle')}<span>Отвечает коротко и задаёт по одному вопросу.</span></li><li class="card">${ic('users')}<span>Подталкивает к живым людям, а не заменяет их.</span></li><li class="card">${ic('phone')}<span>Если станет совсем плохо — покажет, куда позвонить.</span></li></ul>
    <div class="actions"><button class="btn lime" data-act="ob-next">Понятно</button><button class="btn ghost" data-act="ob-back">Назад</button></div>`;
  if (obStep === 2) body = `<h1>Записи хранятся только у тебя</h1><p class="lead">Журнал лежит в памяти этого телефона. Чтобы ИИ ответил, ему уходит только текущий разговор — без имени и без журнала. Наш сервер его не записывает.</p>
    <ul><li class="card">${ic('lock')}<span>Никаких аккаунтов, почты и номера телефона.</span></li><li class="card">${ic('download')}<span>Резервную копию можно скачать в настройках.</span></li><li class="card">${ic('trash-2')}<span>Всё стирается одной кнопкой.</span></li></ul>
    <div class="actions"><button class="btn lime" data-act="ob-done">Начать</button><button class="btn ghost" data-act="ob-back">Назад</button></div>`;
  $('#onboarding').innerHTML = `<div class="ob">${steps}${body}</div>`;
}

/* ===== Home ===== */
function renderHome() {
  const now = new Date(), v = verdict(), d7 = last7(), rated = d7.filter(x => x.r), heavy = rated.filter(x => x.r <= 2).length;
  const st = streak(), wm = weekMoves(), om = openMove();
  const cols = d7.map(x => `<div class="c ${x.r && x.r <= 2 ? 'heavy' : ''}" title="${WD[x.d.getDay()]}">${Array.from({ length: 5 }, (_, i) => `<i class="${x.r && i < x.r ? '' : 'off'}"></i>`).join('')}</div>`).join('');
  const heroTile = rated.length
    ? `<div class="tile hero"><span class="k">Тяжёлые вечера</span><div><span class="dots big">${heavy}</span><span class="unit">/ 7</span></div><div class="cols" aria-hidden="true">${cols}</div><div class="foot">По твоим оценкам дня</div></div>`
    : `<div class="tile hero"><span class="k">Тяжёлые вечера</span><div><span class="dots big">–</span></div><div class="foot" style="margin-top:auto">Оценок пока нет. После разговора оцени день — здесь появится неделя.</div></div>`;
  const moveTile = om
    ? `<div class="tile photo"><span class="k">Ход недели</span><div><span class="dots big">${wm.done}</span><span class="unit">/ ${Math.max(wm.total, 1)}</span></div><button class="glassin ckbtn" data-act="toggle-move" data-id="${om.id}" style="color:#fff"><span class="ck">${''}</span><span><b>${esc(trim(om.move, 48))}</b></span></button></div>`
    : `<div class="tile photo"><span class="k">Ход недели</span><div>${wm.total ? `<span class="dots big">${wm.done}</span><span class="unit">/ ${wm.total}</span>` : `<span class="dots big">–</span>`}</div><div class="glassin"><b>${wm.total ? 'Все ходы сделаны' : 'Ход появится после первого итога дня'}</b></div></div>`;
  const qs = ['Что сегодня забрало больше всего сил?', 'Что сегодня было не так, как хотелось?', 'О чём ты сегодня промолчал?', 'Что сегодня получилось, хоть немного?', 'Что крутится в голове прямо сейчас?'];
  const q = qs[(now.getDate() + now.getMonth()) % qs.length];
  const subline = om ? `В прошлый раз ход: «${esc(trim(om.move, 50))}». Получилось?` : (S.entries.length ? 'Можно коротко. Можно голосом.' : 'Без оценок. Можно коротко, можно голосом.');
  const week = (() => { const mon = addDays(now, -((now.getDay() + 6) % 7)); return Array.from({ length: 7 }, (_, i) => { const d = addDays(mon, i), k = dayKey(d); return `<div><b class="${entryOn(k) ? 'on' : ''} ${k === dayKey() ? 'now' : ''}"></b>${WD[d.getDay()]}</div>`; }).join(''); })();
  const weekCount = (() => { const mon = addDays(now, -((now.getDay() + 6) % 7)); let n = 0; for (let i = 0; i < 7; i++) if (entryOn(dayKey(addDays(mon, i)))) n++; return n; })();
  const initial = (S.profile.name || '').trim().charAt(0).toUpperCase();
  $('#home').innerHTML = `
  <div class="top">${st >= 2 ? `<span class="pill">${ic('flame')}${st} ${plural(st, 'вечер', 'вечера', 'вечеров')} подряд</span>` : `<span class="pill">${ic('moon')}${now.getHours() < 17 ? 'День' : 'Вечер'}</span>`}
   <button class="circ ${initial ? 'ink' : ''}" data-go="settings" aria-label="Настройки">${initial ? esc(initial) : ic('settings')}</button></div>
  <div class="titlerow"><h1>Сегодня</h1><span class="pill">${fmtDay(now)}</span></div>
  <div class="verdict" role="status"><span class="word">${v.w}</span><span class="txt">${esc(v.t)}</span></div>
  <div class="grid2">${heroTile}${moveTile}</div>
  <button class="card prompt" data-go="chat"><span class="chipx">${ic('moon')}Вечерний разговор · 5 мин</span><div class="q">${q}</div><div class="sub" style="margin-top:8px">${subline}</div></button>
  <div class="card week"><div class="hd"><span class="k">Вечера этой недели</span><span class="sub">${weekCount ? `${weekCount} из 7` : 'пока пусто'}</span></div><div class="sq">${week}</div></div>`;
}

/* ===== Chat ===== */
const aiUrl = () => (S.profile.aiUrl || AI_URL || '').trim();
const FALLBACK_Q = [
  'Что сегодня забрало больше всего сил?',
  'А что в этом зависело от тебя?',
  'Если бы можно было переиграть, что бы ты сделал по-другому? Одной фразой.',
  'Какой один маленький ход на завтра? Такой, чтобы точно получилось.',
  'Кому из живых людей можно написать об этом сегодня или завтра? Хотя бы пару слов.'
];
const ACKS = ['Понял.', 'Слышу тебя.', 'Ясно. Это правда выматывает.', 'Принял.', 'Хорошо, что сказал.'];
let busy = false;
function greet() { const n = S.profile.name ? `, ${S.profile.name}` : ''; return `Привет${n}. Как прошёл день? Можно одним словом.`; }
function renderChat() {
  if (!S.chat.messages.length) { S.chat.messages.push({ role: 'ai', text: greet(), t: Date.now() }); S.chat.startedAt = Date.now(); S.chat.step = 0; save(); }
  const offline = !aiUrl();
  const userCount = S.chat.messages.filter(m => m.role === 'me').length;
  const started = new Date(S.chat.startedAt || Date.now());
  $('#chat').innerHTML = `
   <div class="chead"><button class="circ" data-go="home" aria-label="Назад">${ic('chevron-left')}</button><div class="tt"><b>Разговор</b><span class="sub">Сегодня, с ${pad(started.getHours())}:${pad(started.getMinutes())}</span></div>
    <button class="aibadge" data-act="ai-info">${ic('info')}Это ИИ</button></div>
   ${offline ? `<div class="offline">${ic('wifi-off')}<span>ИИ пока не подключён — работает простой режим</span></div>` : ''}
   <div class="msgs" id="msgs" aria-live="polite">${S.chat.messages.map(m => `<div class="m ${m.role === 'me' ? 'me' : 'ai'}">${esc(m.text)}</div>`).join('')}
   ${busy ? '<div class="m ai typing" aria-label="ИИ печатает"><i></i><i></i><i></i></div>' : ''}
   ${userCount >= 2 && !busy ? `<button class="wrapbtn" data-act="to-wrap">${ic('notebook-pen')}Подвести итог дня</button>` : ''}</div>`;
  requestAnimationFrame(() => window.scrollTo(0, document.body.scrollHeight));
}
async function sendMessage(text) {
  text = text.trim(); if (!text || busy) return;
  S.chat.messages.push({ role: 'me', text, t: Date.now() }); save();
  if (isCrisis(text)) openCrisis();
  busy = true; renderChat();
  let reply = null, flag = false;
  const url = aiUrl();
  if (url) {
    try {
      const r = await fetchJSON(url, { mode: 'chat', messages: toApi(S.chat.messages) });
      reply = typeof r.reply === 'string' ? r.reply.trim() : null; flag = !!r.crisis;
    } catch (e) { toast('ИИ не ответил — отвечаю в простом режиме'); }
  }
  if (!reply) { await new Promise(r => setTimeout(r, 650)); reply = fallbackReply(); }
  busy = false;
  S.chat.messages.push({ role: 'ai', text: reply, t: Date.now() }); save();
  if (current === 'chat') renderChat();
  if (flag) openCrisis();
}
function fallbackReply() {
  const i = S.chat.step || 0; S.chat.step = i + 1;
  if (i >= FALLBACK_Q.length) return 'Спасибо, что выговорился. Давай подведём итог дня — нажми «Подвести итог».';
  const ack = i === 0 ? '' : ACKS[(i + S.chat.messages.length) % ACKS.length] + ' ';
  return ack + FALLBACK_Q[i];
}
// local greeting (it contains the name) is never sent; the name is scrubbed from the rest too
const toApi = ms => {
  const i = ms.findIndex(m => m.role === 'me');
  const nm = (S.profile.name || '').trim();
  const scrub = t => nm.length > 1 ? t.split(nm).join('…') : t;
  return (i < 0 ? [] : ms.slice(i)).slice(-24).map(m => ({ role: m.role === 'me' ? 'user' : 'assistant', content: scrub(String(m.text)).slice(0, 1500) }));
};
async function fetchJSON(url, body, ms = 25000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: ctl.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}
$('#composer').addEventListener('submit', e => { e.preventDefault(); const ta = $('#msg'); const v = ta.value; ta.value = ''; autosize(); sendMessage(v); });
const autosize = () => { const ta = $('#msg'); ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 120) + 'px'; };
$('#msg').addEventListener('input', autosize);
$('#msg').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && window.matchMedia('(pointer:fine)').matches) { e.preventDefault(); $('#composer').requestSubmit(); } });
/* voice dictation (if browser supports it) */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
if (SR) {
  const mb = $('#micBtn'); mb.hidden = false; mb.innerHTML = ic('mic');
  mb.addEventListener('click', () => {
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = 'ru-RU'; rec.interimResults = true; const base = $('#msg').value;
    rec.onresult = ev => { let t = ''; for (const r of ev.results) t += r[0].transcript; $('#msg').value = (base ? base + ' ' : '') + t; autosize(); };
    rec.onend = () => { rec = null; mb.classList.remove('rec'); mb.setAttribute('aria-label', 'Надиктовать'); };
    rec.onerror = () => toast('Микрофон недоступен');
    mb.classList.add('rec'); mb.setAttribute('aria-label', 'Остановить запись'); rec.start();
  });
}
$('#sendBtn').innerHTML = ic('arrow-up');

/* ===== Wrap-up ===== */
let draft = null;
function fallbackDraft() {
  const me = S.chat.messages.filter(m => m.role === 'me').map(m => m.text.trim());
  return { was: trim(me[0] || '', 160), learned: trim(me[2] || me[1] || '', 160), move: trim(me[3] || '', 100) };
}
async function makeDraft() {
  draft = { rating: null, ...fallbackDraft(), loading: !!aiUrl() };
  renderWrap();
  if (aiUrl()) {
    try {
      const r = await fetchJSON(aiUrl(), { mode: 'summary', messages: toApi(S.chat.messages) });
      ['was', 'learned', 'move'].forEach(k => { if (typeof r[k] === 'string' && r[k].trim()) draft[k] = trim(r[k], k === 'move' ? 120 : 220); });
    } catch (e) { toast('Черновик собран в простом режиме'); }
    draft.loading = false; if (current === 'wrap') renderWrap();
  }
}
function renderWrap() {
  if (!draft) draft = { rating: null, ...fallbackDraft() };
  const d = draft;
  $('#wrap').innerHTML = `
   <div class="top"><button class="circ" data-go="chat" aria-label="Назад к разговору">${ic('chevron-left')}</button><span class="pill">${fmtDay(new Date())}</span></div>
   <div class="titlerow"><h1>Итог дня</h1></div>
   <label class="lbl" id="rateLbl">Как прошёл день?</label>
   <div class="rates" role="group" aria-labelledby="rateLbl">${[1,2,3,4,5].map(n => `<button type="button" data-act="rate" data-n="${n}" aria-pressed="${d.rating === n}"><b>${n}</b>${RATE_LBL[n]}</button>`).join('')}</div>
   <div class="draftnote">${ic(d.loading ? 'sparkles' : 'pencil')}<span>${d.loading ? 'ИИ собирает черновик…' : (aiUrl() ? 'Черновик собрал ИИ. Поправь, если не так.' : 'Черновик из твоих ответов. Поправь как надо.')}</span></div>
   <label class="lbl" for="fWas">Что было</label><textarea class="field" id="fWas" rows="2" maxlength="300">${esc(d.was)}</textarea>
   <label class="lbl" for="fLearned">Что понял</label><textarea class="field" id="fLearned" rows="2" maxlength="300">${esc(d.learned)}</textarea>
   <label class="lbl" for="fMove">Ход на завтра</label><textarea class="field" id="fMove" rows="2" maxlength="160" placeholder="Один маленький шаг">${esc(d.move)}</textarea>
   <div style="margin-top:20px;display:flex;flex-direction:column;gap:10px"><button class="btn lime" data-act="save-wrap" ${d.rating ? '' : 'disabled'}>${ic('check')}Сохранить в журнал</button>
   <p class="sub" style="text-align:center">${d.rating ? 'Карточка останется только на этом телефоне.' : 'Сначала оцени день — от 1 до 5.'}</p></div>`;
}

/* ===== Journal ===== */
let query = '', showSearch = false;
function entryText(e) { return [e.was, e.learned, e.move].join(' ').toLowerCase(); }
function renderJournal() {
  const all = sorted(), q = query.trim().toLowerCase();
  const list = q ? all.filter(e => entryText(e).includes(q)) : all;
  const first = q ? null : list[0];
  const rest = first ? list.slice(1) : list;
  const now = new Date();
  const doneAll = S.entries.filter(e => e.move && e.moveDone).length, totalMoves = S.entries.filter(e => e.move).length, st = streak();
  const p = pattern();
  const row = e => { const d = fromKey(e.date); return `<div class="card row"><button class="dt" data-act="open-entry" data-id="${e.id}" aria-label="Открыть запись за ${fmtDay(d)}"><b>${d.getDate()}</b><span>${WD[d.getDay()]}</span></button>
     <button class="bd" data-act="open-entry" data-id="${e.id}" style="text-align:left"><b>${esc(trim(e.learned || e.was || 'Без текста', 60))}</b><span class="sub" style="display:block">${e.move ? (e.moveDone ? 'Ход сделан' : 'Ход: ' + esc(trim(e.move, 40))) : (e.rating ? RATE_LBL[e.rating] : 'Запись')}</span></button>
     ${e.move ? `<button class="st ${e.moveDone ? 'done' : ''}" data-act="toggle-move" data-id="${e.id}" aria-label="${e.moveDone ? 'Отметить ход как не сделанный' : 'Отметить ход сделанным'}" aria-pressed="${!!e.moveDone}">${ic('check')}</button>` : ''}</div>`; };
  const todayCard = e => { const d = fromKey(e.date); const isToday = e.date === dayKey(); return `<div class="today"><div class="hd"><span class="over acc">Что понял · ${isToday ? 'сегодня' : fmtDay(d)}</span>${e.rating ? `<span class="over">${RATE_LBL[e.rating]}</span>` : ''}</div>
     <button data-act="open-entry" data-id="${e.id}" style="text-align:left;width:100%"><div class="t">${esc(e.learned || e.was || 'Без текста')}</div></button>
     <div class="ins2"><div><div class="l">Что было</div><div class="v">${esc(trim(e.was || '—', 90))}</div></div>
      <div>${e.move ? `<button class="ckbtn" data-act="toggle-move" data-id="${e.id}" aria-pressed="${!!e.moveDone}"><span class="ck ${e.moveDone ? 'done' : ''}">${e.moveDone ? ic('check') : ''}</span><span><span class="l" style="display:block">Ход на завтра</span><span class="v" style="display:block">${esc(trim(e.move, 70))}</span></span></button>` : `<div class="l">Ход на завтра</div><div class="v">—</div>`}</div></div></div>`; };
  $('#journal').innerHTML = `
   <div class="top"><span class="pill">${ic('calendar')}${MON_N[now.getMonth()]}</span><button class="circ" data-act="toggle-search" aria-label="Поиск" aria-expanded="${showSearch}">${ic(showSearch ? 'x' : 'search')}</button></div>
   <div class="titlerow"><h1>Журнал</h1><span class="pill">${S.entries.length} ${plural(S.entries.length, 'запись', 'записи', 'записей')}</span></div>
   ${showSearch ? `<div class="searchbox"><label for="q" class="sr">Поиск по записям</label><input class="field" id="q" type="search" placeholder="Найти слово в записях" value="${esc(query)}"></div>` : ''}
   ${!S.entries.length ? `<div class="card empty" style="margin-top:12px"><b>Здесь будут твои вечера</b><span class="sub">После разговора ИИ соберёт карточку: что было, что понял и ход на завтра. Можно записать и вручную — кнопка «+».</span></div>` : ''}
   ${first ? todayCard(first) : ''}
   ${p ? `<div class="card pattern"><span class="over" style="color:#A8261C">Похоже на повтор</span><div class="k" style="margin-top:6px">Тяжёлые вечера чаще всего ${WD_LONG[p.wd]}: ${p.max} из ${p.total}.</div><div class="sub" style="margin-top:4px">Посчитано по твоим оценкам за всё время.</div></div>` : ''}
   ${S.entries.length && !q ? `<div class="stats"><div class="card stat"><span class="k">Ходов сделано</span><div><span class="dots big">${doneAll}</span><span class="unit">/ ${totalMoves}</span></div></div><div class="card stat"><span class="k">Вечеров подряд</span><div><span class="dots big">${st}</span></div></div></div>` : ''}
   ${rest.length ? `<div class="secthd"><b>${q ? 'Найдено' : 'Раньше'}</b><span class="sub">${rest.length}</span></div><div class="list">${rest.map(row).join('')}</div>` : (q ? `<div class="card empty" style="margin-top:12px"><b>Ничего не нашлось</b><span class="sub">Попробуй другое слово.</span></div>` : '')}`;
  const qi = $('#q'); if (qi) { qi.addEventListener('input', () => { query = qi.value; const pos = qi.selectionStart; renderJournal(); const n = $('#q'); n.focus(); n.setSelectionRange(pos, pos); }); }
}

/* ===== Entry sheet ===== */
const sheet = $('#sheet');
if (!('closedBy' in HTMLDialogElement.prototype)) {
  sheet.addEventListener('click', ev => { if (ev.target !== sheet) return; const r = sheet.getBoundingClientRect(); if (ev.clientY < r.top) sheet.close(); });
}
function openEntry(id) {
  const e = id ? S.entries.find(x => x.id === id) : { id: null, date: dayKey(), rating: null, was: '', learned: '', move: '', moveDone: false };
  if (!e) return;
  let rating = e.rating;
  const draw = () => {
    $('#sheetBody').innerHTML = `<div class="grab"></div><div class="hd"><h2 id="sheetTitle">${id ? 'Запись' : 'Новая запись'}</h2><button class="circ" data-act="close-sheet" aria-label="Закрыть">${ic('x')}</button></div>
     <label class="lbl" for="eDate">Дата</label><input class="field" id="eDate" type="date" value="${e.date}" max="${dayKey()}">
     <label class="lbl" id="eRateL">Как прошёл день?</label><div class="rates" role="group" aria-labelledby="eRateL">${[1,2,3,4,5].map(n => `<button type="button" data-n="${n}" class="erate" aria-pressed="${rating === n}"><b>${n}</b>${RATE_LBL[n]}</button>`).join('')}</div>
     <label class="lbl" for="eWas">Что было</label><textarea class="field" id="eWas" rows="2" maxlength="300">${esc(e.was)}</textarea>
     <label class="lbl" for="eLearned">Что понял</label><textarea class="field" id="eLearned" rows="2" maxlength="300">${esc(e.learned)}</textarea>
     <label class="lbl" for="eMove">Ход на завтра</label><textarea class="field" id="eMove" rows="2" maxlength="160">${esc(e.move)}</textarea>
     <div class="row2"><button class="btn lime" id="eSave">${ic('check')}Сохранить</button>${id ? `<button class="btn ghost" id="eDel" style="width:auto" aria-label="Удалить запись">${ic('trash-2')}</button>` : ''}</div>`;
    $('#sheetBody').querySelectorAll('.erate').forEach(b => b.onclick = () => { rating = +b.dataset.n; $('#sheetBody').querySelectorAll('.erate').forEach(x => x.setAttribute('aria-pressed', +x.dataset.n === rating)); });
    $('#eSave').onclick = () => {
      const date = $('#eDate').value || dayKey();
      const vals = { date, rating, was: $('#eWas').value.trim(), learned: $('#eLearned').value.trim(), move: $('#eMove').value.trim() };
      if (!vals.was && !vals.learned && !vals.move) { toast('Запиши хотя бы одно поле'); return; }
      if (id) Object.assign(e, vals); else S.entries.push({ ...e, ...vals, id: uid(), created: new Date().toISOString(), source: 'manual' });
      save(); sheet.close(); toast('Сохранено'); RENDER[current] && RENDER[current]();
    };
    const del = $('#eDel'); if (del) { let armed = false; del.onclick = () => { if (!armed) { armed = true; del.innerHTML = 'Точно удалить?'; return; } S.entries = S.entries.filter(x => x.id !== id); save(); sheet.close(); toast('Запись удалена'); RENDER[current] && RENDER[current](); }; }
  };
  draw(); sheet.showModal();
}

/* ===== Settings ===== */
function renderSettings() {
  const p = S.profile;
  $('#settings').innerHTML = `
   <div class="top"><button class="circ" data-go="home" aria-label="Назад">${ic('chevron-left')}</button><span class="pill">Версия ${VERSION}</span></div>
   <div class="titlerow"><h1>Настройки</h1></div>
   <div class="card set">
    <div class="it" style="display:block;padding:12px 0"><label class="lbl" for="sName" style="margin-top:0">Как к тебе обращаться</label><input class="field" id="sName" maxlength="24" value="${esc(p.name)}" placeholder="Можно оставить пустым"></div>
    <button class="it" role="switch" aria-checked="${p.glass}" data-act="toggle-glass"><span class="bd"><b>Стеклянный вид</b><span class="sub">Выключи, если телефон тормозит</span></span><span class="switch"></span></button>
   </div>
   <div class="card set"><div class="it" style="display:block;padding:12px 0"><label class="lbl" for="sAi" style="margin-top:0">Адрес ИИ (Cloudflare Worker)</label>
    <input class="field" id="sAi" type="url" inputmode="url" placeholder="https://….workers.dev" value="${esc(p.aiUrl)}">
    <div style="display:flex;gap:8px;margin-top:10px"><button class="btn ghost" data-act="save-ai" style="height:46px">Сохранить</button><button class="btn ink" data-act="test-ai" style="height:46px">Проверить</button></div>
    <div class="status" id="aiStatus">${aiUrl() ? 'Сейчас: ИИ подключён по адресу выше' + (p.aiUrl ? '' : ' (из кода)') : 'Сейчас: простой режим без ИИ'}</div></div></div>
   <div class="card set">
    <button class="it" data-act="crisis">${ic('phone')}<span class="bd"><b>Экстренная помощь</b><span class="sub">Телефоны доверия и экстренных служб</span></span>${ic('chevron-right')}</button>
    <button class="it" data-act="export">${ic('download')}<span class="bd"><b>Скачать резервную копию</b><span class="sub">Файл JSON со всеми записями</span></span></button>
    <label class="it" for="importFile" style="cursor:pointer">${ic('upload')}<span class="bd"><b>Загрузить копию</b><span class="sub">Заменит записи на этом телефоне</span></span></label><input type="file" id="importFile" accept="application/json,.json" class="sr">
    <button class="it" data-act="erase" style="color:#B3261E">${ic('trash-2')}<span class="bd"><b>Стереть всё</b><span class="sub" style="color:#8C1D18">Записи, разговор и настройки</span></span></button>
   </div>
   <p class="sub" style="margin:16px 6px">Записи хранятся только в памяти этого браузера. Если очистить данные браузера — они пропадут, поэтому иногда скачивай копию.</p>`;
  $('#sName').addEventListener('change', ev => { S.profile.name = ev.target.value.trim().slice(0, 24); save(); toast('Сохранено'); });
  $('#importFile').addEventListener('change', importFile);
}
function importFile(ev) {
  const f = ev.target.files[0]; if (!f) return;
  if (f.size > 5e6) { toast('Файл слишком большой'); return; }
  const r = new FileReader();
  r.onload = () => {
    try {
      const d = JSON.parse(r.result);
      const entries = Array.isArray(d) ? d : d.entries;
      if (!Array.isArray(entries)) throw new Error('bad');
      const clean = entries.filter(validEntry).map(e => ({ id: String(e.id || uid()), date: e.date, created: e.created || new Date().toISOString(), rating: [1,2,3,4,5].includes(+e.rating) ? +e.rating : null, was: String(e.was || '').slice(0, 300), learned: String(e.learned || '').slice(0, 300), move: String(e.move || '').slice(0, 160), moveDone: !!e.moveDone, source: e.source === 'chat' ? 'chat' : 'manual' }));
      if (!confirm(`Заменить записи на этом телефоне (${S.entries.length}) записями из файла (${clean.length})?`)) return;
      S.entries = clean; save(); toast(`Загружено записей: ${clean.length}`); renderSettings();
    } catch (e) { toast('Это не похоже на резервную копию'); }
  };
  r.readAsText(f);
}

/* ===== Crisis ===== */
const LINES = {
  es: { name: 'Испания', items: [['024', 'Линия помощи при суицидальных мыслях', 'Бесплатно, круглосуточно, анонимно'], ['112', 'Экстренные службы', 'Если жизнь в опасности прямо сейчас']] },
  eu: { name: 'Евросоюз', items: [['112', 'Единый номер экстренных служб', 'Работает во всех странах ЕС']] },
  ua: { name: 'Украина', items: [['0 800 33 20 29', 'Кризисная линия Украинского ветеранского фонда', 'Психологи, круглосуточно, бесплатно, для всех'], ['112', 'Экстренные службы', 'Если жизнь в опасности прямо сейчас']] }
};
let crisisCountry = 'eu';
function openCrisis() {
  const dlg = $('#crisis');
  const draw = () => {
    const L = LINES[crisisCountry];
    $('#crisisBody').innerHTML = `<div class="grab"></div><h2 id="crisisTitle">Похоже, сейчас очень тяжело</h2>
     <p class="sub" style="font-size:15px;margin-top:8px;color:#2C2D31">Ты не один. Я всего лишь программа и не могу помочь так, как помогут люди. Позвони — там выслушают, это бесплатно.</p>
     <label class="lbl" for="cSel">Экстренная помощь</label><select class="field" id="cSel">${Object.entries(LINES).map(([k, v]) => `<option value="${k}" ${k === crisisCountry ? 'selected' : ''}>${v.name}</option>`).join('')}</select>
     <div class="lines">${L.items.map(([n, t, s]) => `<a class="line" href="tel:${n.replace(/\s/g, '')}"><span class="bd"><span class="num">${n}</span><span class="sub" style="display:block;color:#2C2D31">${t}</span><span class="sub" style="display:block">${s}</span></span><span class="call" aria-hidden="true">${ic('phone')}</span></a>`).join('')}</div>
     <div class="card" style="margin-top:12px;padding:14px 16px;box-shadow:none;background:#F4FFD6;border-color:#E2F5A5"><b style="font-weight:600">Напиши живому человеку прямо сейчас</b><div class="sub" style="color:#2C2D31;margin-top:4px">Другу, брату, кому угодно. Хватит двух слов: «Мне хреново. Можешь поговорить?»</div></div>
     <div style="display:flex;flex-direction:column;gap:8px;margin-top:14px"><button class="btn ink" data-act="close-crisis">Я в безопасности, вернуться</button></div>`;
    $('#cSel').onchange = ev => { crisisCountry = ev.target.value; draw(); };
  };
  draw(); if (!dlg.open) dlg.showModal();
}
$('#crisis').addEventListener('cancel', e => e.preventDefault());

/* ===== Actions ===== */
const ACT = {
  'ob-next': () => { const n = $('#obName'); if (n) S.profile.name = n.value.trim().slice(0, 24); obStep++; renderOnboarding(); window.scrollTo(0, 0); },
  'ob-back': () => { obStep = Math.max(0, obStep - 1); renderOnboarding(); },
  'ob-done': () => { S.profile.onboarded = true; save(); go('home'); },
  'ai-info': () => { $('#sheetBody').innerHTML = `<div class="grab"></div><div class="hd"><h2 id="sheetTitle">Это ИИ</h2><button class="circ" data-act="close-sheet" aria-label="Закрыть">${ic('x')}</button></div>
     <p style="margin-top:10px;font-size:15.5px;line-height:1.45">Тебе отвечает языковая модель, а не человек. Она не врач и не психолог, может ошибаться и не ставит диагнозов.</p>
     <p style="margin-top:10px;font-size:15.5px;line-height:1.45">На сервер уходит только этот разговор — без журнала и без имени. Наш сервер его не записывает; провайдер модели может хранить запросы до 30 дней для защиты от злоупотреблений.</p>
     <p style="margin-top:10px;font-size:15.5px;line-height:1.45">${aiUrl() ? 'Сейчас ИИ подключён.' : 'Сейчас ИИ не подключён: работает простой режим с заготовленными вопросами.'}</p>
     <div class="row2"><button class="btn ghost" data-act="crisis">${ic('phone')}Экстренная помощь</button></div>`; sheet.showModal(); },
  'close-sheet': () => sheet.close(),
  'to-wrap': () => { go('wrap'); makeDraft(); },
  'rate': b => { draft.was = $('#fWas').value; draft.learned = $('#fLearned').value; draft.move = $('#fMove').value; draft.rating = +b.dataset.n; renderWrap(); },
  'save-wrap': () => {
    if (!draft || !draft.rating) return;
    const vals = { was: $('#fWas').value.trim(), learned: $('#fLearned').value.trim(), move: $('#fMove').value.trim() };
    S.entries.push({ id: uid(), date: dayKey(), created: new Date().toISOString(), rating: draft.rating, ...vals, moveDone: false, source: 'chat' });
    S.chat = { messages: [], step: 0, startedAt: null }; draft = null; save();
    toast('Записано в журнал'); go('journal');
  },
  'toggle-move': b => { const e = S.entries.find(x => x.id === b.dataset.id); if (!e) return; e.moveDone = !e.moveDone; save(); toast(e.moveDone ? 'Ход сделан' : 'Ход снова открыт'); RENDER[current](); },
  'open-entry': b => openEntry(b.dataset.id),
  'new-entry': () => openEntry(null),
  'toggle-search': () => { showSearch = !showSearch; if (!showSearch) query = ''; renderJournal(); if (showSearch) $('#q').focus(); },
  'toggle-glass': () => { S.profile.glass = !S.profile.glass; save(); applyGlass(); renderSettings(); },
  'save-ai': () => { const v = $('#sAi').value.trim(); if (v && !/^https:\/\/[^\s]+$/i.test(v)) { toast('Нужен адрес, который начинается с https://'); return; } S.profile.aiUrl = v; save(); renderSettings(); toast(v ? 'Адрес ИИ сохранён' : 'Включён простой режим'); },
  'test-ai': async () => {
    const st = $('#aiStatus'); const url = ($('#sAi').value.trim() || aiUrl());
    if (!url) { st.className = 'status bad'; st.textContent = 'Адрес не указан — работает простой режим'; return; }
    st.className = 'status'; st.textContent = 'Проверяю…';
    try { const r = await fetchJSON(url, { mode: 'ping' }, 12000); st.className = 'status ok'; st.textContent = r && r.ok ? 'Связь с сервером есть' : 'Сервер ответил, но странно'; }
    catch (e) { st.className = 'status bad'; st.textContent = 'Нет связи: ' + (e.name === 'AbortError' ? 'долго не отвечает' : e.message); }
  },
  'crisis': () => { if (sheet.open) sheet.close(); openCrisis(); },
  'close-crisis': () => $('#crisis').close(),
  'export': () => {
    const data = JSON.stringify({ app: 'evening', version: VERSION, exported: new Date().toISOString(), entries: S.entries }, null, 2);
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' })); a.download = `vecher-backup-${dayKey()}.json`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast('Копия скачана');
  },
  'erase': b => {
    if (b.dataset.armed !== '1') { b.dataset.armed = '1'; b.querySelector('b').textContent = 'Нажми ещё раз, чтобы стереть всё'; setTimeout(() => { if (b.isConnected) { b.dataset.armed = ''; b.querySelector('b').textContent = 'Стереть всё'; } }, 4000); return; }
    localStorage.removeItem(STORE_KEY); S = DEFAULT(); obStep = 0; draft = null; applyGlass(); toast('Всё стёрто'); go('onboarding');
  }
};
const RENDER = { onboarding: renderOnboarding, home: renderHome, chat: renderChat, wrap: renderWrap, journal: renderJournal, settings: renderSettings };

/* ===== Boot ===== */
(function boot() {
  const m = $('#matrix'); const pattern = [0,0,1,1,1,0,0, 0,1,0,0,0,1,0, 1,0,0,2,0,0,1, 0,1,0,0,0,1,0, 0,0,1,1,1,0,0];
  m.innerHTML = pattern.map((v, i) => v ? `<i class="${v === 2 ? 'l' : ''}" style="animation-delay:${((i % 7) + Math.floor(i / 7)) * 0.08}s"></i>` : '<i style="visibility:hidden"></i>').join('');
  applyGlass(); setBg('other');
  const h = location.hash.slice(1);
  const target = !S.profile.onboarded ? 'onboarding' : (SCREENS.includes(h) && h !== 'wrap' ? h : 'home');
  const delay = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 200 : 1300;
  setTimeout(() => { history.replaceState({ s: target }, '', '#' + target); go(target, false); }, delay);
})();

// sticky chat header gets glass once content scrolls under it
addEventListener('scroll', () => {
  const h = document.querySelector('#chat.on .chead');
  if (h) h.classList.toggle('stuck', scrollY > 8);
}, { passive: true });
